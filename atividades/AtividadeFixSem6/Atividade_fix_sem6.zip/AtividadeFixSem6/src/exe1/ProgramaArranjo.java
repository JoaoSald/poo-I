package exe1;

public class ProgramaArranjo {
//Escreva um programa que use um arranjo para encontrar a m�dia de 5 valores double.
	
	public static void main(String[] args) {
	
	double[] vetorDoubleA = {5.0, 9.0, 6.5, 7.5, 8.0};
		//imprime m�dia dos vetor	
  System.out.println("m�dia do vetor: "+((vetorDoubleA[0]+vetorDoubleA[1]+vetorDoubleA[2]+vetorDoubleA[3]+vetorDoubleA[4])/5));
		
		
				
	}
}
